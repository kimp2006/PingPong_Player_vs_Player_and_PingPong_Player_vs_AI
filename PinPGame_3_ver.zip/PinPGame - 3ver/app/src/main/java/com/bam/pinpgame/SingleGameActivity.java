package com.bam.pinpgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.bam.pinpgame.models.DuoGameThread;
import com.bam.pinpgame.models.SingleGameThread;
import com.bam.pinpgame.views.DuoPongTable;
import com.bam.pinpgame.views.SinglePongTable;

public class SingleGameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        startSingle();

    }

    private void startSingle(){
        final SinglePongTable table = findViewById(R.id.pongTable);
        table.setScoreOpponent(findViewById(R.id.tvScoreOpponent));
        table.setScorePlayer(findViewById(R.id.tvPlayerScore));
        table.setStatusView(findViewById(R.id.tvGameStatus));

        SingleGameThread game = table.getGame();
    }

}
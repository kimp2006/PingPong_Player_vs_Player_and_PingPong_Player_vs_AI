package com.bam.pinpgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.bam.pinpgame.models.DuoGameThread;
import com.bam.pinpgame.views.DuoPongTable;

public class DuoGameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_duo_game);
        startDuo();
    }

    private void startDuo(){
        DuoPongTable table = findViewById(R.id.pongTable);
        table.setScoreOpponent(findViewById(R.id.tvScoreOpponent));
        table.setScorePlayer(findViewById(R.id.tvPlayerScore));
        table.setStatusView(findViewById(R.id.tvGameStatus));
        DuoGameThread game = table.getGame();
    }
}
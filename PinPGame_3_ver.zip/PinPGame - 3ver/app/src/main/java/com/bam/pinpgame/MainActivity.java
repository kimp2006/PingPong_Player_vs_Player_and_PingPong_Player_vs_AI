package com.bam.pinpgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    Button single, duo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        single = findViewById(R.id.single);
        duo = findViewById(R.id.duo);


        single.setOnClickListener(v -> {
            startActivity(createIntent(SingleGameActivity.class));
        });

        duo.setOnClickListener(v -> {
            startActivity(createIntent(DuoGameActivity.class));
        });
        
    }

    private Intent createIntent(Class<?> clazz){
        return new Intent(this, clazz);
    }
}